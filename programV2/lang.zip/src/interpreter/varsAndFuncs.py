from src.interpreter.errors import error
from src.interpreter.importLibs import pyLibs
from src.interpreter.globalSGT import funcNameRIP, RIP
import src.interpreter.globalSGT
import src.interpreter.globalSGT as globalSGT

import string
from os import curdir, path
import inspect
import importlib
import json
import sys


bracesInfoVarsAndFuncs = [2]
ifChainsVarsAndFuncs = []

def setBracesInfoAndIfChains(bracesInfo, ifChains, bracesInfoVarsAndFuncs):
    bracesInfoGlobal = bracesInfo
    ifChainsVarsAndFuncs = ifChains

def loadFLT() -> dict:
    try: 
        with open(path.expanduser("~")+"/.nobash/functionTable.json", "r") as f:
            return json.load(f)
    except Exception:
        errors.error(41, [path.expanduser("~")+"/.nobash/functionTable.json"])


flt = loadFLT()
vars = {"main":{}}


def getFuncLibraryName(funcName):
    try:
        libName = flt[funcName.value]["file"].replace(".py", "")
    except Exception as e:
        error(1001, [funcName, "file"])
    return libName


def getFuncLibrary(funcName):
    libName = getFuncLibraryName(funcName)
    if libName in pyLibs.keys():
        return pyLibs[libName]
    error(1002, libName)




def varsAndFuncsNameCheck(name):
    cond1 = not any(lett for lett in name if lett not in string.ascii_letters+"_"+string.digits+":") 
    #cond2 = any([lett for lett in name if name.startswith(lett)])
    #cond2 = any([lett for lett in str(string.ascii_letters) if name.startswith(lett)])
    cond2 = True
    return cond1 and cond2



def isPyFunction(functionName: str) -> bool:
    if functionName.value in flt.keys():
        try:
            if flt[functionName.value]["language"] == "python":
                return True
            return False
        except Exception as e:
            error(1001, [functionName, "language"])
    else:
        error(72, functionName)




def isVarOrFunc(name): # C
    #if name in flt.keys():
    #    return "function"
    #elif name.startswith("ret") and len(name) > 3:
    #    if not any([lett for lett in name[3:] if name not in "1234567890"]):
    #        return "rettype"
    return "variable"


def getNbFuncLine(functionName):
    return flt[functionName.value]["line"]


def setVar(varName, varVal, scope=None):
    if not scope:
        scope = funcNameRIP[-1]
    if scope not in vars.keys():
        vars[scope] = {}
    vars[scope][varName] = varVal


def getBaseFunctionName(functionName): # Remove the instance of the function from the end of the function
    functionName = functionName[::-1]
    newName = ""
    for letter in functionName:
        if letter not in "1234567890":
            newName += letter
    return newName[::-1]


def passNbParameters(arguments, funcName):
    reqArgs = []
    scope = funcName
    funcName = getBaseFunctionName(funcName)
    if "arguments" in flt[funcName].keys():
        reqArgs = flt[funcName]["arguments"]
        if len(reqArgs) != len(arguments):
            error(142, [funcName, len(arguments), len(reqArgs)])
        for indx, arg in enumerate(arguments):
            setVar(reqArgs[indx], arg, scope)
    else:
        error(91, [len(arguments), 0])
            
def getBraceIdFromEndInstruction(instructionNumber):
    for brace in src.interpreter.globalSGT.bracesInfoGlobal:
        if str(brace[3].value) == str(instructionNumber):
            return brace[0]
    error(1052, [ID])


def getBraceIdFromStartInstruction(instructionNumber):
    for brace in src.interpreter.globalSGT.bracesInfoGlobal:
        if str(brace[1].value) == str(instructionNumber):
            return brace[0]
    error(1052, [ID])

def setObrsVars(bracesInfo):
    for braces in bracesInfo:
        ID = str(braces[0].value)
        setVar(f"cbrs{ID}", str(braces[1].value))
        setVar(f"obrs{ID}", str(braces[3].value))


def getIfChainRan(bracketID):
    for entry in globalSGT.ifChains:
        if str(bracketID.value) not in [str(id) for id in entry]:
            continue
        break
    for ifChainID in entry:
        if bracketID.value <= ifChainID.value:
            break
        if getVar("$ifResult"+str(ifChainID.value)):
            return True
    return False
    

def setRetVars(varVal):
    if varVal == None:
        return
    varName = "ret"+str(RIP[-1])
    setVar(varName, varVal, funcNameRIP[-1])


def getVar(varName):
    value, exists = hasVar(varName)
    if exists:
        return value
    error(101, varName)


def hasVar(varName):
    scope = funcNameRIP[-1]
    if type(varName) != str:
        varName = varName.value
    if varName in vars["main"]:
        return vars["main"][varName], True
    if scope in vars.keys():
        if varName in vars[scope]:
            return vars[scope][varName], True
    return None, False

def replaceVars(arguments, funcName):
    newArgs = []
    scope = funcNameRIP[-1]
    start = -1
    noReplaceList = ["__doFor__", "__setAddVariable__",  "__setSubVariable__", "__setMulVariable__", "__setDivVariable__"]
    if funcName.value in noReplaceList :
        start = 1
    elif funcName.value == "__setVariable__":
        start = len(arguments) - 1
    for indx, arg in enumerate(arguments):
        if arg.type == "variable" and indx >= start:
            arg = getVar(arg)
        newArgs.append(arg)
    return newArgs


def isNbFunction(functionName):
    if functionName.value in flt.keys():
        try:
            if flt[functionName.value]["language"] == "nobash":
                return True
            return False
        except Exception as e:
            error(1001, [functionName, "language"])
    else:
        error(72, functionName)


def addPyFuncs(libName):
    module = pyLibs[libName]
    for name, obj in inspect.getmembers(module):
        if inspect.isfunction(obj) and inspect.getmodule(obj) == module:
            flt[name] = {"language":"python", "file":libName}

    


def addNbFunctions(functions):
    for func in functions:
        if len(func) < 2:
            error(10031)
        flt[func[0].value] = {"language":"nobash", "line":func[1]}
        if len(func) > 2:
            flt[func[0].value]["arguments"] = [ parameter.value for parameter in func[2:]]

