from data.pylibraries.errors import error as e


error = e