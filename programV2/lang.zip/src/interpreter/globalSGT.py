

RIP = [0]
funcNameRIP = ["main"]

def init():
    global bracesInfoGlobal
    bracesInfoGlobal = [2]