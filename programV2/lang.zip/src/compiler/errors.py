


def error(errorNumber, *info):
    print(f"Found {errorNumber} with following info:", *info)
    exit(errorNumber)