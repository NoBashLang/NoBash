



def turnLinesToDict(linesList):
    return {str(index): [line] for index, line in enumerate(linesList)}