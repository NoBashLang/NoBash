from src.interpreter.token import Token


def pow(x, y):
    nums = ["int", "float"]
    if x.type in nums and y.type in nums:
        return Token(x.value ** y.value, "float")
    error(304, [x.type, y.type])